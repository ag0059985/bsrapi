public class RoleClaimsMiddleware
{
    private readonly RequestDelegate _next;

    public RoleClaimsMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        if (context.User.Identity.IsAuthenticated)
        {
            var userId = context.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (userId != null)
            {
                //var roles = await userRoleService.GetUserRolesAsync(userId);
                var roles = new List<string> { "superadmin", "test2", "test3" };
                var claims = roles.Select(role => new Claim(ClaimTypes.Role, role));

                var appIdentity = new ClaimsIdentity(claims);
                context.User.AddIdentity(appIdentity);
            }
        }

        await _next(context);
    }
}
