﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Identity.Web;

namespace firstcontainer.Controllers;

[Authorize] 
[ApiController]
[Route("[controller]")]

public class WeatherForecastController : ControllerBase
{
     const string scopeRequiredByApi = "access_as_user";
    private static readonly string[] Summaries = new[]
    {
         "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

    private readonly ILogger<WeatherForecastController> _logger;

    public WeatherForecastController(ILogger<WeatherForecastController> logger)
    {
        _logger = logger;
    }

    [HttpGet]
    
    public IEnumerable<WeatherForecast> Get()
    {
        
        AuthHelper.UserHasAnyAcceptedScopes(HttpContext, new string[] {"access_as_user"});
        //var claim = HttpContext.User.Claims;
        ClaimsPrincipal principal = HttpContext.User as ClaimsPrincipal;  
        if (null != principal)  
        {  
        foreach (Claim claim in principal.Claims)  
        {  
            _logger.LogInformation("CLAIM TYPE: " + claim.Type + "; CLAIM VALUE: " + claim.Value + "</br>");  
        }  

        }  
        
        return Enumerable.Range(1, 4).Select(index => new WeatherForecast
        {
            Date = DateTime.Now.AddDays(index),
            TemperatureC = Random.Shared.Next(-20, 55),
            Summary = Summaries[Random.Shared.Next(Summaries.Length)]
        })
        .ToArray();
    }
}

